from distutils.core import setup

setup(
  name         = 'print_list',
  version      = '1.2.0',
  py_modules   = ['print_list'],
  author       = 'thanhlt-1007',
  author_email = 'le.tan.thanh@sun-asterisk.com',
  url          = 'https://github.com/thanhlt-1007',
  description  = 'A simplele printer of nested list'
)
